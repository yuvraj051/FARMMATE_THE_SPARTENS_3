package com.example.farmmateshop;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class logi extends AppCompatActivity {

    // Declare TextViews for user details
    private TextView idTextView, firstNameTextView, lastNameTextView, mobileNumberTextView, emailTextView, passTextView, addressTextView;
    private Button logoutButton;

    // URL to fetch user details
    private String fetchUrl = "http://192.168.74.37/farmmate/users/getDetails.php";
    private String userMobile; // Dynamic mobile number

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logi);

        // Initialize TextViews
        idTextView = findViewById(R.id.id);
        firstNameTextView = findViewById(R.id.firstname);
        lastNameTextView = findViewById(R.id.lastname);
        mobileNumberTextView = findViewById(R.id.mobilenumber);
        emailTextView = findViewById(R.id.email);
        passTextView = findViewById(R.id.pass);
        addressTextView = findViewById(R.id.address);

        // Initialize logout button
        logoutButton = findViewById(R.id.logoutButton);

        // Retrieve mobile number from intent
        userMobile = getIntent().getStringExtra("mobile_number");

        // Check if mobile number is received
        if (userMobile != null && !userMobile.isEmpty()) {
            fetchUserDetails(); // Fetch user details from the backend
        } else {
            Toast.makeText(this, "Mobile number not found", Toast.LENGTH_SHORT).show();
        }

        // Logout button click listener
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the Registration activity
                startActivity(new Intent(logi.this, Registration.class));
                finish(); // Close the current activity
            }
        });
    }

    // Method to fetch user details from the backend
    private void fetchUserDetails() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, fetchUrl + "?mobilenumber=" + userMobile,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            // Parse the JSON response
                            JSONObject jsonObject = new JSONObject(response);

                            // Check if the response contains an error
                            if (jsonObject.has("error")) {
                                Toast.makeText(logi.this, jsonObject.getString("error"), Toast.LENGTH_SHORT).show();
                                return;
                            }

                            // Populate the TextViews with the fetched data
                            idTextView.setText(jsonObject.getString("id"));
                            firstNameTextView.setText(jsonObject.getString("firstname"));
                            lastNameTextView.setText(jsonObject.getString("lastname"));
                            mobileNumberTextView.setText(jsonObject.getString("mobilenumber"));
                            emailTextView.setText(jsonObject.getString("email"));
                            passTextView.setText(jsonObject.getString("pass")); // Avoid displaying passwords in production
                            addressTextView.setText(jsonObject.getString("address"));

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(logi.this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(logi.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                });

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}