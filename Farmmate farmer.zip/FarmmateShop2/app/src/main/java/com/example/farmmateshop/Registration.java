package com.example.farmmateshop;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Registration extends AppCompatActivity {

    private EditText firstName, lastName, mobileNumber, email, password,add;
    private Button register;
    private ProgressBar loading;
    private TextView loginNow;
    private ProgressDialog progressDialog;
    private String uploadUrl = "http://192.168.74.37/farmmate/users/register.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regi);

        firstName = findViewById(R.id.firstname);
        lastName = findViewById(R.id.lastname);
        mobileNumber = findViewById(R.id.mobilenumber);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        register = findViewById(R.id.submit);
        add= findViewById(R.id.address);
        loading = new ProgressBar(this);
        loginNow = findViewById(R.id.loginNow);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Registering...");

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        loginNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Registration.this, login.class));
            }
        });
    }

    private void registerUser() {
        String fName = firstName.getText().toString().trim();
        String lName = lastName.getText().toString().trim();
        String mobNum = mobileNumber.getText().toString().trim();
        String mail = email.getText().toString().trim();
        String pass = password.getText().toString().trim();
        String adds = add.getText().toString().trim();

        if (fName.isEmpty() || lName.isEmpty() || mobNum.isEmpty() || mail.isEmpty() || pass.isEmpty() || adds.isEmpty() ) {
            Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.show();
        loading.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, uploadUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        loading.setVisibility(View.GONE);

                        if (response.trim().equalsIgnoreCase("success")) {
                            Toast.makeText(Registration.this, "Registration Successful!", Toast.LENGTH_LONG).show();
                            startActivity(new Intent(Registration.this, login.class));
                            finish();
                        } else {
                            Toast.makeText(Registration.this, "Error: " + response, Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError errorResponse) {
                        progressDialog.dismiss();
                        loading.setVisibility(View.GONE);
                        Toast.makeText(Registration.this, "Network Error: " + errorResponse.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("firstname", fName);
                params.put("lastname", lName);
                params.put("mobilenumber", mobNum);
                params.put("email", mail);
                params.put("pass", pass);
                params.put("address",adds);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
