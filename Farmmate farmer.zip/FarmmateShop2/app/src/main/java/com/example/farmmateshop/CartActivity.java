package com.example.farmmateshop;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartActivity extends AppCompatActivity {
    RecyclerView cartRecyclerView;
    TextView totalPrice;
    Button checkoutButton;
    List<Product> cartItems;
    CartAdapter cartAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        // Initialize views
        cartRecyclerView = findViewById(R.id.cartRecyclerView);
        totalPrice = findViewById(R.id.totalPrice);
        checkoutButton = findViewById(R.id.checkoutButton);

        // Get cart items from CartManager
        cartItems = CartManager.getInstance().getCartItems();

        // Setup RecyclerView
        cartAdapter = new CartAdapter(this, cartItems);
        cartRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        cartRecyclerView.setAdapter(cartAdapter);

        // Calculate and display total price
        updateTotalPrice();

        // Handle checkout button click
        checkoutButton.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(this, "Your cart is empty!", Toast.LENGTH_SHORT).show();
            } else {
                // Navigate to the checkout confirmation screen
                proceedToCheckout();
            }
        });
    }

    private void updateTotalPrice() {
        double total = 0;
        for (Product product : cartItems) {
            total += product.getPrice();
        }
        totalPrice.setText("Total: ₹" + String.format("%.2f", total));
    }

    private void proceedToCheckout() {
        // Navigate to the checkout confirmation activity
        Intent intent = new Intent(this, CheckoutActivity.class);
        intent.putExtra("total_price", totalPrice.getText().toString()); // Pass the total price
        startActivity(intent);

        // Clear the cart after checkout
        CartManager.getInstance().clearCart();
        Toast.makeText(this, "Order placed successfully!", Toast.LENGTH_SHORT).show();
        finish(); // Close the CartActivity
    }
}