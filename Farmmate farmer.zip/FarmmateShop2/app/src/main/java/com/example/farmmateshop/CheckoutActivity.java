package com.example.farmmateshop;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CheckoutActivity extends AppCompatActivity {
    TextView totalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        // Initialize views
        totalPrice = findViewById(R.id.totalPrice);

        // Get the total price from the intent
        String total = getIntent().getStringExtra("total_price");
        totalPrice.setText(total);

        // Use a Handler to delay the redirection
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Create an intent to start the Orders activity
                Intent intent = new Intent(CheckoutActivity.this, orders.class);

                startActivity(intent);

                // Finish the current activity to remove it from the back stack
                finish();
            }
        }, 4000); // 4000 milliseconds = 4 seconds
    }
}