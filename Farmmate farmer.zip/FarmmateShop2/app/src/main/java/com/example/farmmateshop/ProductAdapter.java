package com.example.farmmateshop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    private Context context;
    private List<Product> productList;

    public ProductAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = productList.get(position);

        // Bind product data to views
        holder.productName.setText(product.getProductName());
        holder.productDetails.setText(product.getDetails());
        holder.productPrice.setText("₹" + product.getPrice());
        holder.productVillages.setText("Available in: " + product.getVillages());
        holder.productStock.setText("Stock: " + product.getStock());

        // Load product image using Glide
        Glide.with(context)
                .load(product.getImageUrl()) // Assuming getImageUrl() returns the image URL
                .placeholder(R.drawable.placeholder) // Placeholder image while loading
                .error(R.drawable.error) // Error image if loading fails
                .into(holder.productImage);

        // Set click listener for "Add to Cart" button
        holder.addToCartButton.setOnClickListener(v -> {
            // Add the product to the cart
            addToCart(product);
            Toast.makeText(context, product.getProductName() + " added to cart!", Toast.LENGTH_SHORT).show();
        });

        // Set click listener for "View Details" button (if needed)
        holder.viewDetailsButton.setOnClickListener(v -> {
            // Handle view details logic
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    // Method to add a product to the cart
    private void addToCart(Product product) {
        // Add the product to your cart data structure
        CartManager.getInstance().addToCart(product);
    }

    // ViewHolder class
    public static class ProductViewHolder extends RecyclerView.ViewHolder {
        ShapeableImageView productImage;
        TextView productName, productDetails, productPrice, productVillages, productStock;
        MaterialButton addToCartButton, viewDetailsButton;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.productImage);
            productName = itemView.findViewById(R.id.productName);
            productDetails = itemView.findViewById(R.id.productDetails);
            productPrice = itemView.findViewById(R.id.productPrice);
            productVillages = itemView.findViewById(R.id.productVillages);
            productStock = itemView.findViewById(R.id.productStock);
            addToCartButton = itemView.findViewById(R.id.addToCartButton);
            viewDetailsButton = itemView.findViewById(R.id.viewDetailsButton);
        }
    }
}