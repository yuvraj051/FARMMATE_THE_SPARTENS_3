package com.example.farmmateshop;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class orders extends AppCompatActivity {
    private RecyclerView recyclerView;
    private OrdersAdapter adapter;
    private List<String> orderItems;
    private TextView totalAmountTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        // Initialize views
        recyclerView = findViewById(R.id.recyclerView);
        totalAmountTextView = findViewById(R.id.totalAmountTextView);

        // Retrieve the total amount from the intent
        String totalAmount = getIntent().getStringExtra("total_amount");
        totalAmountTextView.setText("Total Amount: " + totalAmount);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        orderItems = new ArrayList<>();
        adapter = new OrdersAdapter(orderItems);
        recyclerView.setAdapter(adapter);

        // Add sample data to the RecyclerView (replace with your actual data)
        orderItems.add("Item 1 - $10");
        orderItems.add("Item 2 - $20");
        orderItems.add("Item 3 - $30");
        adapter.notifyDataSetChanged();
    }
}