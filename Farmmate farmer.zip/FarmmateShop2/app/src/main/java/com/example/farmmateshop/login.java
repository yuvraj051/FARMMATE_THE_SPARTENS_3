
package com.example.farmmateshop;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;

import java.util.HashMap;
import java.util.Map;

public class login extends AppCompatActivity {

    private TextInputEditText phones, password;
    private Button submit;
    private ProgressBar loading;
    private TextView error, registerNow;
    private ProgressDialog progressDialog;
    private String loginUrl = "http://192.168.74.37/farmmate/users/login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        phones = findViewById(R.id.phone);
        password = findViewById(R.id.password);
        submit = findViewById(R.id.submit);
        loading = findViewById(R.id.loading);
        error = findViewById(R.id.error);
        registerNow = findViewById(R.id.registerNow);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Logging in...");

        submit.setOnClickListener(v -> loginUser());
        registerNow.setOnClickListener(v -> startActivity(new Intent(login.this, Registration.class)));
    }

    private void loginUser() {
        String phone = phones.getText().toString().trim();
        String pass = password.getText().toString().trim();

        if (phone.isEmpty() || pass.isEmpty()) {
            error.setVisibility(View.VISIBLE);
            error.setText("All fields are required!");
            return;
        }

        progressDialog.show();
        loading.setVisibility(View.VISIBLE);
        error.setVisibility(View.GONE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, loginUrl,
                response -> {
                    progressDialog.dismiss();
                    loading.setVisibility(View.GONE);
                    if (response.trim().equalsIgnoreCase("success")) {
                        startActivity(new Intent(login.this, FarmerActivity.class).putExtra("mobile_number", phone));
                        finish();
                    } else {
                        error.setVisibility(View.VISIBLE);
                        error.setText("Invalid phone number or password!");
                    }
                },
                errorResponse -> {
                    progressDialog.dismiss();
                    loading.setVisibility(View.GONE);
                    error.setVisibility(View.VISIBLE);
                    error.setText("Network Error! Please try again.");
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("phone", phone);
                params.put("password", pass);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}