package com.example.farmmate

data class Coord(
    val lat: Double,
    val lon: Double
)