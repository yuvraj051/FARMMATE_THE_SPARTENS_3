package com.example.farmmate

data class Wind(
    val deg: Int,
    val speed: Double
)