package com.example.farmmate

data class Clouds(
    val all: Int
)