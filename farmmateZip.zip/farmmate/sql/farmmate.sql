-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2025 at 05:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `farmmate`
--

-- --------------------------------------------------------

--
-- Table structure for table `approved_farmer`
--

CREATE TABLE `approved_farmer` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `mobilenumber` varchar(15) NOT NULL,
  `village` varchar(100) NOT NULL,
  `jilla` varchar(100) NOT NULL,
  `certificatenumber` varchar(50) NOT NULL,
  `certificate_image` text NOT NULL,
  `pass` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `qrcode` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `approved_farmer`
--

INSERT INTO `approved_farmer` (`id`, `firstname`, `lastname`, `mobilenumber`, `village`, `jilla`, `certificatenumber`, `certificate_image`, `pass`, `created_at`, `qrcode`) VALUES
(3, 'Yagnik', 'yagnikhariyani7878@gmail.com', '6359438336', 'Chikhali', 'Amreli', 'hpop123', 'cert/hpop123.jpg', 'yagnik123', '2025-03-23 04:02:49', '../farmer/qrcodes/hpop123.png');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_name`, `quantity`, `price`, `image_url`) VALUES
(1, 1, 'Banana', 1, 10.00, 'http://192.168.74.37/farmmate/jay/uploads/product/1_Fruits_Banana.jpg'),
(2, 1, 'Banana', 1, 10.00, 'http://192.168.74.37/farmmate/jay/uploads/product/1_Fruits_Banana.jpg'),
(3, 1, 'Tomato', 1, 8.00, 'http://192.168.74.37/farmmate/jay/uploads/product/1_Vegetable_Tomato.jpg'),
(4, 1, 'Tomato', 1, 8.00, 'http://192.168.74.37/farmmate/jay/uploads/product/1_Vegetable_Tomato.jpg'),
(5, 1, 'Banana', 1, 10.00, 'http://192.168.74.37/farmmate/jay/uploads/product/1_Fruits_Banana.jpg'),
(6, 1, 'Banana', 1, 10.00, 'http://192.168.74.37/farmmate/jay/uploads/product/1_Fruits_Banana.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cart1`
--

CREATE TABLE `cart1` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart1`
--

INSERT INTO `cart1` (`id`, `user_id`, `product_id`, `product_name`, `price`, `quantity`, `created_at`) VALUES
(1, 1, 1, 'Banana', 10.00, 4, '2025-03-22 14:20:28'),
(2, 1, 7, 'Tomato', 8.00, 1, '2025-03-22 14:21:18'),
(3, 6, 1, 'Banana', 10.00, 4, '2025-03-22 12:33:42'),
(4, 6, 3, 'Orange', 8.00, 2, '2025-03-22 12:34:21'),
(5, 6, 2, 'Banana', 10.00, 4, '2025-03-22 12:34:55'),
(8, 30, 2, 'Banana', 10.00, 1, '2025-03-22 14:42:06'),
(9, 30, 3, 'Orange', 8.00, 2, '2025-03-22 14:42:12'),
(10, 30, 8, 'Apple', 7.00, 1, '2025-03-22 14:42:19'),
(12, 28, 1, 'Banana', 10.00, 3, '2025-03-22 19:25:01'),
(13, 28, 2, 'Banana', 10.00, 1, '2025-03-22 22:15:02'),
(14, 6, 12, 'Apple', 1.00, 2, '2025-03-22 23:56:39'),
(15, 6, 15, 'Orange', 1.00, 1, '2025-03-22 23:57:29'),
(16, 28, 12, 'Apple', 1.00, 1, '2025-03-22 23:59:18');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `farmmate_hander`
--

CREATE TABLE `farmmate_hander` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farmmate_hander`
--

INSERT INTO `farmmate_hander` (`id`, `username`, `password`) VALUES
(6, 'yuvraj', '$2y$10$fTj7pufJO8V4//t.b/ecMepXpmURMF.BookneuZcEQUTaiA/WgNNW'),
(7, 'jay', '$2y$10$nKBpYboeFDUhPYJztUlhlu5WcXfoi9wsak20JCubH6kFaKeD05YhO'),
(8, 'yagnik', '$2y$10$WA69hVLTdhn2cg04sY2GPOT5JuYEM3aoOe7mM8FcHJQkz0n/ccCgS'),
(9, 'tushar', '$2y$10$S29l6ZiojjftVMhj2osk4.ksm75LQOIFdWhFRqz3FhgIE.mcuNzXm');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_price`, `address`, `payment_method`, `status`) VALUES
(1, 1, 500.00, 'chikhali ', 'Cash on Delivery', 'Cancelled'),
(2, 1, 500.00, 'chikhali ', 'Cash on Delivery', 'Cancelled'),
(3, 1, 500.00, 'Surat ', 'Cash on Delivery', 'Cancelled'),
(4, 1, 500.00, 'Surat ', 'Cash on Delivery', NULL),
(5, 1, 500.00, 'Surat ', 'Cash on Delivery', NULL),
(6, 1, 500.00, 'Surat ', 'Cash on Delivery', NULL),
(7, 1, 500.00, 'Surat ', 'Cash on Delivery', NULL),
(8, 1, 500.00, 'Surat ', 'Cash on Delivery', NULL),
(9, 1, 500.00, 'Surat ', 'Cash on Delivery', NULL),
(10, 30, 33.00, 'amreli', 'cod', 'Pending'),
(11, 28, 38.00, 'amreli', 'cod', 'Cancelled'),
(12, 28, 38.00, 'amreli', 'cod', 'Pending'),
(13, 28, 41.00, 'amreli', 'cod', 'Cancelled');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `product_type` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `villages` text DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `certificate_number` varchar(255) DEFAULT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `certificate_photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `mobile_number`, `product_type`, `product_name`, `details`, `price`, `villages`, `stock`, `certificate_number`, `product_image`, `certificate_photo`) VALUES
(9, '134347', 'Vegetable', 'Tomato', 'yyahg', 5.00, 'rsfs', 5454, '5262', '134347_Vegetable_Tomato.jpg', '5262.jpg'),
(10, '9537220866', 'Vegetable', 'Tomato', 'Very Testy And Fresh ', 1.00, 'Chikhali ', 12, '23012004', '9537220866_Vegetable_Tomato.jpg', '23012004.jpg'),
(11, '9537220866', 'Vegetable', 'Potato', 'Very Testy And Fresh ', 1.00, 'Chikhali ', 10, '23012004', '9537220866_Vegetable_Potato.jpg', '23012004.jpg'),
(12, '9537220866', 'Fruits', 'Apple', 'Very Testy And Fresh ', 1.00, 'Chikhali ', 50, '23012004', '9537220866_Fruits_Apple.jpg', '23012004.jpg'),
(13, '9537220866', 'Fruits', 'Banana', 'Very Testy And Fresh ', 1.00, 'Chikhali ', 25, '23012004', '9537220866_Fruits_Banana.jpg', '23012004.jpg'),
(14, '9537220866', 'Fruits', 'Orange', 'Very Testy And Fresh ', 1.00, 'Chikhali ', 5, '23012004', '9537220866_Fruits_Orange.jpg', '23012004.jpg'),
(15, '9537220866', 'Fruits', 'Orange', 'Very Testy And Fresh ', 1.00, 'Chikhali ', 5, '23012004', '9537220866_Fruits_Orange.jpg', '23012004.jpg'),
(16, '6359438336', 'Vegetable', 'Onion', 'Good quality ', 7.00, 'Chikhli ', 10, '34', '6359438336_Vegetable_Onion.jpg', '34.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `rejected_farmer`
--

CREATE TABLE `rejected_farmer` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `mobilenumber` varchar(15) NOT NULL,
  `village` varchar(100) NOT NULL,
  `jilla` varchar(100) NOT NULL,
  `certificatenumber` varchar(50) NOT NULL,
  `certificate_image` text NOT NULL,
  `pass` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reason` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rejected_farmer`
--

INSERT INTO `rejected_farmer` (`id`, `firstname`, `lastname`, `mobilenumber`, `village`, `jilla`, `certificatenumber`, `certificate_image`, `pass`, `created_at`, `reason`) VALUES
(5, 'Yagnik', 'yagnikhariyani7878@gmail.com', '635438336', 'Chikhli', 'Amreli', 'NPOPSG12430034', 'cert/NPOPSG12430034.jpg', 'Yagnik123', '2025-03-23 04:03:23', 'your certificate is not authorized');

-- --------------------------------------------------------

--
-- Table structure for table `request_farmer`
--

CREATE TABLE `request_farmer` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `mobilenumber` varchar(15) NOT NULL,
  `village` varchar(100) NOT NULL,
  `jilla` varchar(100) NOT NULL,
  `certificatenumber` varchar(50) NOT NULL,
  `certificate_image` text NOT NULL,
  `pass` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `mobilenumber` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `mobilenumber`, `email`, `pass`, `address`) VALUES
(26, 'yagnik', 'hariyani', '63594383336', 'yagnikhariyani778@gmail.com', '1234', 'surat'),
(27, 'Tushar', 'Rathod', '8401743731', 'hariyani7878@gmail.com', '1234', 'chikhli'),
(28, 'yuvraj', 'vala', '9979108573', 'vyuvraj051@gmail.com', 'yuvraj', 'yuvraj'),
(30, 'jay', 'vaghamashi', '1234567890', 'jay@gmail.com', 'jay', 'surat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approved_farmer`
--
ALTER TABLE `approved_farmer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart1`
--
ALTER TABLE `cart1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `farmmate_hander`
--
ALTER TABLE `farmmate_hander`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rejected_farmer`
--
ALTER TABLE `rejected_farmer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request_farmer`
--
ALTER TABLE `request_farmer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobilenumber` (`mobilenumber`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approved_farmer`
--
ALTER TABLE `approved_farmer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart1`
--
ALTER TABLE `cart1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `farmmate_hander`
--
ALTER TABLE `farmmate_hander`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `request_farmer`
--
ALTER TABLE `request_farmer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
