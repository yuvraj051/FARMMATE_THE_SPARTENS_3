<?php
// adminnoti.php
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendAdminNotification($firstname, $lastname, $mobilenumber, $village, $jilla, $certificatenumber) {
    $admin_email = "admin@example.com"; // Replace with the admin's email address
    $subject = "New Farmer Registration";
    $message = "
        <h3>A new farmer has registered:</h3>
        <p><b>Name:</b> $firstname $lastname</p>
        <p><b>Mobile:</b> $mobilenumber</p>
        <p><b>Village:</b> $village</p>
        <p><b>Jilla:</b> $jilla</p>
        <p><b>Certificate Number:</b> $certificatenumber</p>
    ";

    $mail = new PHPMailer(true);
    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'your-email@gmail.com'; // Replace with your email
        $mail->Password   = 'your-email-password'; // Replace with your email password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use TLS
        $mail->Port       = 587; // SMTP port for TLS

        // Email Settings
        $mail->setFrom('your-email@gmail.com', 'Farmer Registration System');
        $mail->addAddress($admin_email);
        $mail->Subject = $subject;
        $mail->isHTML(true);
        $mail->Body    = $message;

        // Send email
        $mail->send();
        return "✅ Admin Notified Successfully!";
    } catch (Exception $e) {
        return "❌ Error Sending Email: " . $mail->ErrorInfo;
    }
}
?>