<?php
require 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobilenumber = $_POST["phone"];
    $password = $_POST["password"];

    // Prepare the SQL query
    $sql = "SELECT * FROM approved_farmer WHERE mobilenumber = ? AND pass = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $mobilenumber, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        echo "success";
    } else {
        echo "Invalid credentials!";
    }

    $stmt->close();
}

$conn->close();
 