<?php
require 'conn.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $mobilenumber = $_POST["mobilenumber"];
    $village = $_POST["village"];
    $jilla = $_POST["jilla"];
    $certificatenumber = $_POST["certificatenumber"];
    $password = $_POST["pass"];
    $certificate_image_path = "";

    // ✅ Handle Base64 Image Upload
    if (isset($_POST["certificate_image"])) {
        $imageData = base64_decode($_POST["certificate_image"]);

        // Save the image with certificate number as filename
        $imageName = $certificatenumber . ".jpg";
        $targetDirectory = "cert/";
        $certificate_image_path = $targetDirectory . $imageName;

        // Ensure directory exists
        if (!file_exists($targetDirectory)) {
            mkdir($targetDirectory, 0777, true);
        }

        // Save the image file
        if (!file_put_contents($certificate_image_path, $imageData)) {
            echo "❌ Error Saving Image!";
            exit;
        }
    }

    // ✅ Save Farmer Data in Database
    $sql = "INSERT INTO request_farmer (firstname, lastname, mobilenumber, village, jilla, certificatenumber, certificate_image, pass) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $firstname, $lastname, $mobilenumber, $village, $jilla, $certificatenumber, $certificate_image_path, $password);

    if ($stmt->execute()) {
        echo "✅ Farmer Registered Successfully!";

        // ✅ Send Email to Admin
        $admin_email = "rathodtushar162003@gmail.com";  // Change to actual admin email
        $subject = "New Farmer Registration";
        $message = "
            <h3>A new farmer has registered:</h3>
            <p><b>Name:</b> $firstname $lastname</p>
            <p><b>Mobile:</b> $mobilenumber</p>
            <p><b>Village:</b> $village</p>
            <p><b>Jilla:</b> $jilla</p>
            <p><b>Certificate Number:</b> $certificatenumber</p>
            <p><b>Certificate Image:</b> <a href='http://yourwebsite.com/$certificate_image_path'>View Certificate</a></p>
        ";

        try {
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'verifyresumecraft@gmail.com'; // ✅ Use Environment Variables
            $mail->Password   = 'eyvmsmjmibxdbfuv'; // ✅ Use Environment Variables
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;

            // Email Settings
            $mail->setFrom('verifyresumecraft@gmail.com', 'Farmer Registration System');
            $mail->addAddress($admin_email);
            $mail->Subject = $subject;
            $mail->isHTML(true);
            $mail->Body    = $message;

            if ($mail->send()) {
                echo "✅ Admin Notified Successfully!";
            } else {
                echo "❌ Error Sending Email to Admin.";
            }
        } catch (Exception $e) {
            echo "❌ Email Error: " . $mail->ErrorInfo;
        }

    } else {
        echo "❌ Database Error: " . $stmt->error;
    }

    $conn->close();
}
?>
