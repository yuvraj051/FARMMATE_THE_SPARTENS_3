<?php
include 'conn.php'; // Include database connection file

$phone = $_POST['phone'];

$tables = ['request_farmer', 'approved_farmer', 'rejected_farmer'];

foreach ($tables as $table) {
    $sql = "SELECT * FROM $table WHERE mobilenumber = '$phone'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo $table;
        exit();
    }
}

echo "not_found";
$conn->close();
?>
