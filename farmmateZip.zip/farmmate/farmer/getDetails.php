<?php
require 'conn.php';

if (isset($_GET["mobilenumber"])) {
    $mobilenumber = $_GET["mobilenumber"];

    $sql = "SELECT firstname, lastname, mobilenumber, village, jilla, certificatenumber, certificate_image FROM approved_farmer WHERE mobilenumber = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $mobilenumber);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($firstname, $lastname, $mobilenumber, $village, $jilla, $certificatenumber, $certificate_image);
        $stmt->fetch();

        $imageData = file_get_contents($certificate_image);
        $base64Image = base64_encode($imageData);

        $response = array(
            "firstname" => $firstname,
            "lastname" => $lastname,
            "mobilenumber" => $mobilenumber,
            "village" => $village,
            "jilla" => $jilla,
            "certificatenumber" => $certificatenumber,
            "certificate_image" => $base64Image
        );

        echo json_encode($response);
    } else {
        echo json_encode(["error" => "No user found"]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["error" => "Invalid request"]);
}