<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

$userMobileNumber = $_GET['user_mobile_number'];

if (empty($userMobileNumber)) {
    echo json_encode(['status' => 'error', 'message' => 'User mobile number is required.']);
    exit;
}

$host = "localhost";
$dbname = "product_db";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $conn->connect_error]));
}

$query = "
    SELECT c.id AS cart_id, c.quantity, p.id AS product_id, p.product_name, p.price, p.product_image
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_mobile_number = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userMobileNumber);
$stmt->execute();
$result = $stmt->get_result();

$cartItems = [];
while ($row = $result->fetch_assoc()) {
    $cartItems[] = $row;
}

echo json_encode(['status' => 'success', 'cart_items' => $cartItems]);

$stmt->close();
$conn->close();
?>