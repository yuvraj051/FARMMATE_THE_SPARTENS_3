<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

$host = "localhost";
$dbname = "farmmate";
$username = "root";
$password = "";

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $conn->connect_error]));
}

// Query to fetch all products
$query = "SELECT * FROM products";
$result = $conn->query($query);

// Check if the query was successful
if (!$result) {
    die(json_encode(['status' => 'error', 'message' => 'Failed to fetch products: ' . $conn->error]));
}

// Fetch products and store them in an array
$products = [];
while ($row = $result->fetch_assoc()) {
    // Construct the full URL for the product image
    $row['product_image'] = 'http://192.168.74.37/farmmate/jay/uploads/product/' . $row['product_image'];
    $products[] = $row;
}

// Return the products as a JSON response
echo json_encode(['status' => 'success', 'products' => $products]);

// Close the database connection
$conn->close();
?>