<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farmmate";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_POST['user_id'];
$product_name = $_POST['product_name'];
$quantity = $_POST['quantity'];
$price = $_POST['price'];
$image_url = $_POST['image_url'];

$sql = "INSERT INTO cart (user_id, product_name, quantity, price, image_url)
VALUES ('$user_id', '$product_name', '$quantity', '$price', '$image_url')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Product added to cart successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Error: " . $sql . "<br>" . $conn->error]);
}

$conn->close();
?>