<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farmmate";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$id = $_POST['id'];
$stock = $_POST['stock'];

// Update stock in the database
$sql = "UPDATE products SET stock = '$stock' WHERE id = '$id'";

if ($conn->query($sql) === TRUE) {
    echo "Stock updated successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>