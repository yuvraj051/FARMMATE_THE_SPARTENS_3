<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

$host = "localhost";
$dbname = "farmmate";
$username = "root";
$password = "";

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $conn->connect_error]));
}

// Get mobile number from request
$mobile_number = isset($_GET['mobile_number']) ? $_GET['mobile_number'] : '';

if (empty($mobile_number)) {
    die(json_encode(['status' => 'error', 'message' => 'Mobile number is required']));
}

// Query to fetch products for the given mobile number
$query = "SELECT * FROM products WHERE mobile_number = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $mobile_number);
$stmt->execute();
$result = $stmt->get_result();

// Check if the query was successful
if (!$result) {
    die(json_encode(['status' => 'error', 'message' => 'Failed to fetch products: ' . $conn->error]));
}

// Fetch products and store them in an array
$products = [];
while ($row = $result->fetch_assoc()) {
    $row['product_image'] = 'http://192.168.74.37/farmmate/jay/uploads/product/' . $row['product_image'];
    $products[] = $row;
}

// Return the products as a JSON response
echo json_encode(['status' => 'success', 'products' => $products]);

// Close the database connection
$conn->close();
?>
