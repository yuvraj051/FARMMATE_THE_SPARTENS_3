<?php
// Debugging: Log received files and form data
error_log("Received Files: " . print_r($_FILES, true));
error_log("Received POST Data: " . print_r($_POST, true));

// Check if files are uploaded
if (!isset($_FILES['product_image']) || !isset($_FILES['certificate_photo'])) {
    echo json_encode(["status" => "error", "message" => "No file uploaded."]);
    exit;
}

// Database connection
$host = "localhost";
$dbname = "farmmate";
$username = "root"; // Default XAMPP username
$password = "";     // Default XAMPP password

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Define upload directories
$productUploadDir = 'C:/xampp/htdocs/farmmate/jay/uploads/product/';
$certificateUploadDir = 'C:/xampp/htdocs/farmmate/jay/uploads/cert/';

// Create directories if they don't exist
if (!is_dir($productUploadDir)) {
    mkdir($productUploadDir, 0777, true); // Create the product upload directory
}
if (!is_dir($certificateUploadDir)) {
    mkdir($certificateUploadDir, 0777, true); // Create the certificate upload directory
}

// Get form data
$mobileNumber = $_POST['mobile_number'];
$productType = $_POST['product_type'];
$productName = $_POST['product_name'];
$certificateNumber = $_POST['certificate_number'];

// Generate custom file names
$productImageName = $mobileNumber . "_" . $productType . "_" . $productName . ".jpg";
$certificatePhotoName = $certificateNumber . ".jpg";

// Process product image
$productImagePath = $productUploadDir . $productImageName;
if (!move_uploaded_file($_FILES['product_image']['tmp_name'], $productImagePath)) {
    echo json_encode(["status" => "error", "message" => "Failed to upload product image."]);
    exit;
}

// Process certificate photo
$certificatePhotoPath = $certificateUploadDir . $certificatePhotoName;
if (!move_uploaded_file($_FILES['certificate_photo']['tmp_name'], $certificatePhotoPath)) {
    echo json_encode(["status" => "error", "message" => "Failed to upload certificate photo."]);
    exit;
}

// Insert data into the database
$stmt = $conn->prepare("INSERT INTO products (mobile_number, product_type, product_name, details, price, villages, stock, certificate_number, product_image, certificate_photo) VALUES (:mobile_number, :product_type, :product_name, :details, :price, :villages, :stock, :certificate_number, :product_image, :certificate_photo)");
$stmt->bindParam(':mobile_number', $_POST['mobile_number']);
$stmt->bindParam(':product_type', $_POST['product_type']);
$stmt->bindParam(':product_name', $_POST['product_name']);
$stmt->bindParam(':details', $_POST['details']);
$stmt->bindParam(':price', $_POST['price']);
$stmt->bindParam(':villages', $_POST['villages']);
$stmt->bindParam(':stock', $_POST['stock']);
$stmt->bindParam(':certificate_number', $_POST['certificate_number']);
$stmt->bindParam(':product_image', $productImageName);
$stmt->bindParam(':certificate_photo', $certificatePhotoName);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Product inserted successfully."]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to insert product."]);
}
?>