<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farmmate";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_POST['user_id'];
$total_price = $_POST['total_price'];
$address = $_POST['address'];
$payment_method = $_POST['payment_method'];

$sql = "INSERT INTO orders (user_id, total_price, address, payment_method)
VALUES ('$user_id', '$total_price', '$address', '$payment_method')";

if ($conn->query($sql) === TRUE) {
    echo "Order placed successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>