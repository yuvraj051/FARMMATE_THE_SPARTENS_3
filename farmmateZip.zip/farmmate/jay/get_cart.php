<?php
$conn = new mysqli("localhost", "root", "", "product_db");

$user_id = $_GET['user_id'];
$sql = "SELECT * FROM cart WHERE user_id = '$user_id'";
$result = $conn->query($sql);

$cartItems = array();
while ($row = $result->fetch_assoc()) {
    $cartItems[] = $row;
}

echo json_encode($cartItems);
$conn->close();
?>
