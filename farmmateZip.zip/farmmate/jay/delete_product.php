<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farmmate";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get product ID from the request
$id = $_POST['id'];

// Delete product from the database
$sql = "DELETE FROM products WHERE id = '$id'";

if ($conn->query($sql) === TRUE) {
    echo "Product deleted successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>