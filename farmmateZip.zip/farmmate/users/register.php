<?php
include 'conn.php'; // Including the database connection file

// Get form data
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$mobilenumber = $_POST['mobilenumber'];
$email = $_POST['email'];
$password = $_POST['pass']; // Storing plain text password
$address = $_POST['address']; // New Address field

// Validate fields
if (empty($firstname) || empty($lastname) || empty($mobilenumber) || empty($email) || empty($password) || empty($address)) {
    echo "All fields are required!";
    exit;
}

// Insert data into the database without hashing the password
$sql = "INSERT INTO users (firstname, lastname, mobilenumber, email, password, address) 
        VALUES ('$firstname', '$lastname', '$mobilenumber', '$email', '$password', '$address')";

if ($conn->query($sql) === TRUE) {
    echo "success";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
