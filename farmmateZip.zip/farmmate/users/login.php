<?php
include 'conn.php'; // Including the database connection file

// Check if form data is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    // Use Prepared Statements to prevent SQL Injection
    $sql = "SELECT * FROM users WHERE mobilenumber = ? AND pass = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $phone, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "success";
    } else {
        echo "Invalid phone or password!";
    }

    $stmt->close();
} else {
    echo "Invalid request!";
}

$conn->close();
?>
