<?php
require 'conn.php'; // Include the database connection file

if (isset($_GET["mobilenumber"])) {
    $mobilenumber = $_GET["mobilenumber"];

    // Prepare SQL query to fetch user details
    $sql = "SELECT id, firstname, lastname, mobilenumber, email, pass, address FROM users WHERE mobilenumber = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $mobilenumber);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Bind the result to variables
        $stmt->bind_result($id, $firstname, $lastname, $mobilenumber, $email, $pass, $address);
        $stmt->fetch();

        // Create a response array
        $response = array(
            "id" => $id,
            "firstname" => $firstname,
            "lastname" => $lastname,
            "mobilenumber" => $mobilenumber,
            "email" => $email,
            "pass" => $pass, // Note: Avoid returning passwords in production
            "address" => $address
        );

        // Return the response as JSON
        echo json_encode($response);
    } else {
        // If no user is found, return an error message
        echo json_encode(["error" => "No user found with the provided mobile number"]);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    // If mobilenumber is not provided, return an error message
    echo json_encode(["error" => "Invalid request. Mobile number is required."]);
}
?>