<style>
        body { display: flex; margin: 0; background-color: #f4f7f6; }
        .sidebar { width: 250px; height: 100vh; background: #343a40; color: white; padding: 20px; position: fixed; }
        .sidebar h2 { font-size: 22px; }
        .sidebar a { display: block; color: white; padding: 10px; text-decoration: none; border-radius: 5px; }
        .sidebar a:hover { background: #495057; }
        .content { margin-left: 260px; padding: 20px; width: 100%; }
        .search-bar { max-width: 500px; margin-bottom: 20px; }
        .table-container { overflow-x: auto; max-height: 75vh; }
        .table thead { position: sticky; top: 0; background: #007bff; color: #fff; z-index: 1; }
        .img-thumbnail { max-width: 60px; border-radius: 5px; }
    </style>