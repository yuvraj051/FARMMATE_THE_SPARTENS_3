<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}
?>
<?php
// Database connection
include 'conn.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Handle accept/reject actions
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["farmer_id"]) && isset($_POST["action"])) {
    $farmer_id = $_POST["farmer_id"];
    $action = $_POST["action"];

    if ($action == "accept") {
        // Fetch farmer data
        $fetch_sql = "SELECT * FROM request_farmer WHERE id = ?";
        $stmt = $conn->prepare($fetch_sql);
        $stmt->bind_param("i", $farmer_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
    
            // Move farmer to approved table
            include "phpqrcode/qrlib.php";
            $text = "https://pgsindia-ncof.gov.in/certificate/" . $row['certificatenumber']; 
            $file = "../farmer/qrcodes/" . $row['certificatenumber'] . ".png";
            QRcode::png($text, $file, QR_ECLEVEL_L, 10, 2);
    
            $insert_sql = "INSERT INTO approved_farmer (id, firstname, lastname, mobilenumber, village, jilla, certificatenumber, certificate_image, created_at , pass , qrcode)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_sql);
            $stmt->bind_param("issssssssss", 
                $row['id'], $row['firstname'], $row['lastname'], 
                $row['mobilenumber'], $row['village'], $row['jilla'], 
                $row['certificatenumber'], $row['certificate_image'], 
                $row['created_at'], $row['pass'], $file
            );
    
            if ($stmt->execute()) {
                // Send approval email
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'verifyresumecraft@gmail.com'; // Use an actual email
                    $mail->Password   = 'eyvmsmjmibxdbfuv'; // Use an App Password (not your Gmail password)
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port       = 587;
    
                    // Email Settings
                    $mail->setFrom('verifyresumecraft@gmail.com', 'Natural Farming System FARMMATE');
                    $mail->addAddress($row['lastname']); // Send to farmer's email
                    
                    $mail->Subject = "Your Farmer Registration is Approved!";
                    $mail->Body    = "Dear " . $row['firstname'] . " " . $row['lastname'] . ",\n\n" .
                                     "Congratulations! Your farmer registration has been approved.\n\n" .
                                     "Your Certificate Number: " . $row['certificatenumber'] . "\n" .
                                     "You can now access our platform.\n\n" .
                                     "Thank you for joining us.\n\n" .
                                     "Best Regards,\n" .
                                     "Natural Farming Team";
    
                    $mail->send();
                } catch (Exception $e) {
                    error_log("Approval Email Error: " . $mail->ErrorInfo);
                }
    
                // Delete farmer from request table
                $delete_sql = "DELETE FROM request_farmer WHERE id = ?";
                $stmt = $conn->prepare($delete_sql);
                $stmt->bind_param("i", $farmer_id);
                $stmt->execute();
    
                echo "<script>alert('Farmer approved and email sent!'); window.location.href='verify.php';</script>";
            }
        }
    }
     elseif ($action == "reject") {
        // Fetch farmer data
        $fetch_sql = "SELECT * FROM request_farmer WHERE id = ?";
        $stmt = $conn->prepare($fetch_sql);
        $stmt->bind_param("i", $farmer_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        }
    
        // Move farmer to rejected table
        $insert_sql = "INSERT INTO rejected_farmer (id, firstname, lastname, mobilenumber, village, jilla, certificatenumber, certificate_image, created_at , pass , reason)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("issssssssss", 
            $row['id'], $row['firstname'], $row['lastname'], 
            $row['mobilenumber'], $row['village'], $row['jilla'], 
            $row['certificatenumber'], $row['certificate_image'], 
            $row['created_at'], $row['pass'], $_POST['reason']
        );
    
        if ($stmt->execute()) {
            // Send rejection email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'verifyresumecraft@gmail.com';
                $mail->Password   = 'eyvmsmjmibxdbfuv';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;
    
                // Email Settings
                $mail->setFrom('verifyresumecraft@gmail.com', 'Natural Farming System FARMMATE');
                $mail->addAddress($row['lastname']); // Send to farmer's email
                
                $mail->Subject = "Your Farmer Registration is Rejected";
                $mail->Body    = "Dear " . $row['firstname'] . " " . $row['lastname'] . ",\n\n" .
                                 "We regret to inform you that your farmer registration has been rejected.\n\n" .
                                 "Reason: " . $_POST['reason'] . "\n\n" .
                                 "If you believe this was a mistake, please contact support.\n\n" .
                                 "Best Regards,\n" .
                                 "Natural Farming Team";
    
                $mail->send();
            } catch (Exception $e) {
                error_log("Rejection Email Error: " . $mail->ErrorInfo);
            }
    
            // Delete farmer from request table
            $delete_sql = "DELETE FROM request_farmer WHERE id = ?";
            $stmt = $conn->prepare($delete_sql);
            $stmt->bind_param("i", $farmer_id);
            $stmt->execute();
    
            echo "<script>alert('Farmer rejected and email sent!'); window.location.href='verify.php';</script>";
        }
    }
}

// Fetch farmer requests
$search_query = isset($_GET["search"]) ? $_GET["search"] : "";
$sql = "SELECT * from request_farmer WHERE 
        firstname LIKE ? OR 
        lastname LIKE ? OR 
        mobilenumber LIKE ? OR 
        village LIKE ? OR 
        certificatenumber LIKE ?";
$stmt = $conn->prepare($sql);
$search_param = "%$search_query%";
$stmt->bind_param("sssss", $search_param, $search_param, $search_param, $search_param, $search_param);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Farmer Verification</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-dark ">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="index.php">FarmMate</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link text-white" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="verify.php">request</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="farmers.php">farmers</a></li>
                    <li class="nav-item"><a class="nav-link btn btn-danger text-white" href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

<div class="container mt-4">
    <h2 class="mb-4">Farmer Verification</h2>
    <form class="d-flex mb-3" method="GET">
        <input type="text" class="form-control me-2" name="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search farmers...">
        <button class="btn btn-primary" type="submit">Search</button>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Mobile Number</th>
                    <th>Village</th>
                    <th>Jilla</th>
                    <th>Certificate Number</th>
                    <th>Certificate</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['firstname']; ?></td>
                    <td><?php echo $row['lastname']; ?></td>
                    <td><?php echo $row['mobilenumber']; ?></td>
                    <td><?php echo $row['village']; ?></td>
                    <td><?php echo $row['jilla']; ?></td>
                    <td><?php echo $row['certificatenumber']; ?></td>
                    <td><a href="../farmer/<?php echo $row['certificate_image']; ?>" target="_blank">View</a></td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="farmer_id" value="<?php echo $row['id']; ?>">
                            <textarea name="reason" class="form-control mb-2" placeholder="Reason for rejection"></textarea>
                            <button class="btn btn-success" name="action" value="accept">Accept</button>
                            <button class="btn btn-danger" name="action" value="reject">Reject</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>