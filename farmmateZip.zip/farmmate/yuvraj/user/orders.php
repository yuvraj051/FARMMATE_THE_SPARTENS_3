<?php
// session_start();
include '../conn.php';
include '..//user/session_check.php';

// Database connection parameters
// Query to fetch orders
$u = $_SESSION["user_id"];
$sql = "SELECT id, user_id, total_price, address, payment_method, status FROM orders WHERE user_id = '".$_SESSION["user_id"]."'"; 
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetch all orders
$orders = $stmt->get_result();

// Handle cancel order
if (isset($_GET['cancel_order_id'])) {
    $order_id = $_GET['cancel_order_id'];
    
    // Ensure the user can only cancel their own orders
    $check_order_sql = "SELECT user_id, status FROM orders WHERE id = ?";
    $check_stmt = $conn->prepare($check_order_sql);
    $check_stmt->bind_param("i", $order_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows > 0) {
        $order = $result->fetch_assoc();
        
        if ($order['user_id'] == $_SESSION['user_id'] && $order['status'] !== 'Cancelled') {
            // Proceed with cancelling the order
            $cancel_sql = "UPDATE orders SET status = 'Cancelled' WHERE id = ?";
            $cancel_stmt = $conn->prepare($cancel_sql);
            $cancel_stmt->bind_param("i", $order_id);
            $cancel_stmt->execute();
            
            // Redirect to the same page to refresh the list
            header("Location: ".$_SERVER['PHP_SELF']);
            exit;
        } else {
            // Order already cancelled or user not authorized to cancel
            echo "<script>alert('You cannot cancel this order.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order List</title>
    
    <?php include 'head.php'; ?>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }

        /* Header */
        header {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        /* Table styling */
        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            font-size: 16px;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        td {
            color: #555;
        }

        .container {
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #333;
            font-size: 24px;
            margin-top: 30px;
        }

        /* Button styles */
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            background-color: #4CAF50;
            color: white;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #45a049;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        .cancel-link {
            color: #ff0000;
            text-decoration: none;
            font-size: 14px;
        }

        .cancel-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <?php include 'header.php'; ?>

    <div class="container">
        <h2>Order List</h2>

        <!-- Order Table -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Total Price</th>
                    <th>Address</th>
                    <th>Payment Method</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($orders->num_rows > 0): ?>
                    <?php while ($order = $orders->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($order['id']); ?></td>
                            <td><?php echo htmlspecialchars($order['user_id']); ?></td>
                            <td>$<?php echo number_format($order['total_price'], 2); ?></td>
                            <td><?php echo htmlspecialchars($order['address']); ?></td>
                            <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                            <td><?php echo htmlspecialchars($order['status']); ?></td>
                            <td>
                                <?php if ($order['status'] !== 'Cancelled'): ?>
                                    <a href="?cancel_order_id=<?php echo $order['id']; ?>" class="cancel-link" onclick="return confirm('Are you sure you want to cancel this order?')">Cancel Order</a>
                                <?php else: ?>
                                    <span>Order Cancelled</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center;">No orders found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <a href="index.php" class="btn">Back to Dashboard</a>
    </div>

    <footer>
        <p>&copy; 2025 farmmate Company. All Rights Reserved.</p>
    </footer>

</body>
</html>
