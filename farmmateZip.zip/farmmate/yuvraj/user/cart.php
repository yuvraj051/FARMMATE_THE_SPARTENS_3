<?php
session_start();
include '../conn.php'; // Include database connection

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please login to view your cart!'); window.location.href='login_form.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id']; // Get logged-in user's ID

// Fetch cart items for the logged-in user
$sql = "SELECT * FROM cart1 WHERE user_id = '$user_id'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart - FarmMate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'header.php' ?>
    <div class="container mt-5">
        <h2 class="text-center">My Cart</h2>
        <?php if ($result->num_rows > 0) { ?>
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $grandTotal = 0;
                    while ($row = $result->fetch_assoc()) {
                        $total = $row['price'] * $row['quantity'];
                        $grandTotal += $total;
                    ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                            <td>₹<?php echo number_format($row['price'], 2); ?></td>
                            <td><?php echo $row['quantity']; ?></td>
                            <td>₹<?php echo number_format($total, 2); ?></td>
                            <td>
                                <a href="remove_cart_item.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Remove</a>
                            </td>
                        </tr>
                    <?php } ?>
                    <tr>
                        <td colspan="3" class="text-end"><strong>Grand Total:</strong></td>
                        <td><strong>₹<?php echo number_format($grandTotal, 2); ?></strong></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        <?php } else { ?>
            <p class="text-center">Your cart is empty. <?php echo $_SESSION['user_id']; ?></p>
        <?php } ?>
        <?php if ($result->num_rows > 0) { ?>
    <div class="text-end mt-3">
        <a href="checkout.php" class="btn btn-success">Proceed to Checkout</a>
    </div>
<?php } ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
