<?php
session_start();
include '../conn.php'; // Database connection

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please login to continue!'); window.location.href='login_form.php';</script>";
    exit();
}

// Check if cart item ID is provided
if (isset($_GET['id'])) {
    $cart_id = intval($_GET['id']); // Ensure it's an integer
    $user_id = $_SESSION['user_id'];

    // Delete item only if it belongs to the logged-in user
    $sql = "DELETE FROM cart1 WHERE id = '$cart_id' AND user_id = '$user_id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Item removed from cart!'); window.location.href='cart.php';</script>";
    } else {
        echo "<script>alert('Error removing item!'); window.location.href='cart.php';</script>";
    }
} else {
    echo "<script>alert('Invalid request!'); window.location.href='cart.php';</script>";
}

$conn->close();
?>
