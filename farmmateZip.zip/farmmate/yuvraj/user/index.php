<?php
// Database connection
include '../conn.php';

// Fetch unique product categories
$categoryQuery = "SELECT DISTINCT product_type FROM products WHERE product_type IS NOT NULL AND product_type != ''";
$categoryResult = $conn->query($categoryQuery);

// Handle filters
$selectedCategory = isset($_GET['category']) ? $_GET['category'] : '';
$searchQuery = isset($_GET['search']) ? trim($_GET['search']) : '';

// Fetch products based on category and search query
$query = "SELECT * FROM products WHERE 1"; // Default query
$params = [];

if (!empty($selectedCategory)) {
    $query .= " AND product_type = ?";
    $params[] = $selectedCategory;
}

if (!empty($searchQuery)) {
    $query .= " AND product_name LIKE ?";
    $params[] = "%" . $searchQuery . "%";
}

$stmt = $conn->prepare($query);

if (!empty($params)) {
    $types = str_repeat("s", count($params)); // Generate type string for bind_param
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$productResult = $stmt->get_result();

// Set Base URL for images dynamically
$base_url = "http://" . $_SERVER['SERVER_NAME'] . "/farmmate/jay/uploads/product/";
$base_url_c = "http://" . $_SERVER['SERVER_NAME'] . "/farmmate/farmer/cert/";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Product Listing</title>
    <?php include 'head.php'; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php include 'header.php'; ?>

<!-- Carousel Section -->
<div id="productCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#productCarousel" data-bs-slide-to="0" class="active"></button>
        <button type="button" data-bs-target="#productCarousel" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#productCarousel" data-bs-slide-to="2"></button>
    </div>

    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="./img/vegetable-farm.gif" class="d-block w-100 rounded" style="height: 400px; object-fit: cover;" alt="Farming Image 1">
            <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-75 p-3 rounded">
                <h5 class="text-white">Fresh & Organic Farming</h5>
                <p class="text-white">Support local farmers and enjoy natural products.</p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="./img/fruit-2048x1367.jpg" class="d-block w-100 rounded" style="height: 400px; object-fit: cover;" alt="Farming Image 2">
            <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-75 p-3 rounded">
                <h5 class="text-white">Sustainable Agriculture</h5>
                <p class="text-white">Eco-friendly farming practices for a better future.</p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="./img/5c40a519dde8670e86761478.jpg" class="d-block w-100 rounded" style="height: 400px; object-fit: cover;" alt="Farming Image 3">
            <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-75 p-3 rounded">
                <h5 class="text-white">Healthy & Organic Produce</h5>
                <p class="text-white">Enjoy fresh, chemical-free vegetables and fruits.</p>
            </div>
        </div>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#productCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
    </button>
</div>

<!-- Product Listing Section -->
<div class="container mt-4">
    <h2 class="text-center mb-4">🛒 Available Products</h2>

    <!-- Category & Search Filters -->
    <form method="GET" class="mb-4">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <select name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php while ($row = $categoryResult->fetch_assoc()) : ?>
                        <option value="<?= htmlspecialchars($row['product_type']); ?>" <?= ($selectedCategory == $row['product_type']) ? 'selected' : ''; ?>>
                            <?= ucfirst(htmlspecialchars($row['product_type'])); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="col-md-4">
                <input type="text" name="search" class="form-control" placeholder="🔍 Search product..." value="<?= htmlspecialchars($searchQuery); ?>">
            </div>

            <div class="col-md-2 text-center">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </div>
    </form>
    <div class="row">
    <?php while ($row = $productResult->fetch_assoc()) : ?>
        <div class="col-md-3 mb-3">
            <div class="card h-100 shadow-sm border-0">
                <img src="<?= $base_url . $row['product_image']; ?>" class="card-img-top" alt="<?= htmlspecialchars($row['product_name']); ?>" style="height: 180px; object-fit: cover;">
                <div class="card-body p-2">
                    <h6 class="card-title text-truncate"><?= htmlspecialchars($row['product_name']); ?></h6>
                    <p class="card-text text-muted small"><?= substr(htmlspecialchars($row['details']), 0, 50); ?>...</p>
                    <h6 class="text-success mb-1">₹<?= number_format($row['price'], 2); ?></h6>
                    <p class="small"><strong>Stock:</strong> <?= htmlspecialchars($row['stock']); ?></p>
                    <p class="small"><strong>Village:</strong> <?= htmlspecialchars($row['villages']); ?></p>

                    <!-- Add to Cart Form -->
                    <form action="addToCart.php" method="POST">
                        <input type="hidden" name="product_id" value="<?= $row['id']; ?>">
                        <input type="hidden" name="product_type" value="<?= htmlspecialchars($row['product_type']); ?>">
                        <input type="hidden" name="product_name" value="<?= htmlspecialchars($row['product_name']); ?>">
                        <input type="hidden" name="details" value="<?= htmlspecialchars($row['details']); ?>">
                        <input type="hidden" name="price" value="<?= $row['price']; ?>">
                        <input type="hidden" name="villages" value="<?= htmlspecialchars($row['villages']); ?>">
                        <input type="hidden" name="stock" value="<?= $row['stock']; ?>">
                        <input type="hidden" name="mobile_number" value="<?= htmlspecialchars($row['mobile_number']); ?>">
                        <input type="hidden" name="certificate_number" value="<?= htmlspecialchars($row['certificate_number']); ?>">
                        <input type="hidden" name="product_image" value="<?= $row['product_image']; ?>">
                        <input type="hidden" name="certificate_photo" value="<?= $row['certificate_photo']; ?>">
                        <input type="hidden" name="quantity" value="1">

                        <a href="addToCart.php?pid=<?=$row['id']; ?>" class="btn btn-sm btn-warning w-100">🛒 Add to Cart</a>

                    </form>

                </div>
            </div>
        </div>
    <?php endwhile; ?>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


</body>
</html>

<?php $conn->close(); ?>
