<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please login...'); window.location.href='login_form.php';</script>";
    exit();
}

// If you actually want to log out the user later, use session_destroy().
?>
