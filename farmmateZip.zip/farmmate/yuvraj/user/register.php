<?php
session_start(); // Start the session
include '../conn.php'; // Database connection

// Get form data
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$mobilenumber = $_POST['mobilenumber'];
$email = $_POST['email'];
$password = $_POST['pass']; // Storing plain text password (Consider hashing)
$address = $_POST['address'];

// Validate fields
if (empty($firstname) || empty($lastname) || empty($mobilenumber) || empty($email) || empty($password) || empty($address)) {
    echo "All fields are required!";
    exit;
}

// Hash the password before saving to the database
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert data into the database
$sql = "INSERT INTO users (firstname, lastname, mobilenumber, email, pass, address) 
        VALUES ('$firstname', '$lastname', '$mobilenumber', '$email', '$hashed_password', '$address')";

if ($conn->query($sql) === TRUE) {
    // Get the inserted user ID
    $user_id = $conn->insert_id;

    // Create session variables
    $_SESSION['user_id'] = $user_id;
    $_SESSION['firstname'] = $firstname;
    $_SESSION['email'] = $email;

    // Redirect to the homepage
    header("Location: index.php");
    exit();
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
