<?php
include "../conn.php";
$order_id = $_GET['order_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <?php include 'head.php' ?>
</head>
<body>
    <?php include 'header.php' ?>
    <h2>Thank You!</h2>
    <p>Your order has been placed successfully. Order ID: <?= htmlspecialchars($order_id) ?></p>
    <a href="index.php">Continue Shopping</a>
</body>
</html>
