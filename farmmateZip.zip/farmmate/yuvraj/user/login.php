<?php
session_start(); // Start the session

include '../conn.php'; // Database connection

// Check if form data is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prevent SQL Injection
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    // Query to check the user in the database
    $sql = "SELECT * FROM users WHERE email='$email' AND pass='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Create session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['firstname'] . ' ' . $user['lastname'];

        // Redirect to index.php
        header("location: index.php");
        exit(); // Important to prevent further script execution
    } else {
        echo "<script>alert('Invalid email or password!'); window.location.href='login_form.php';</script>";
    }
} else {
    echo "Invalid request!";
}

$conn->close();
?>
