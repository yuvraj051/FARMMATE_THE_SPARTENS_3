<?php
session_start();
include "../conn.php"; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment_method'];
    $total_price = $_POST['total_price'];
    $status = "Pending"; // Default status

    // Insert into orders table
    $order_sql = "INSERT INTO orders (user_id, total_price, address, payment_method, status)
                  VALUES (?, ?, ?, ?, ?)";
    $order_stmt = $conn->prepare($order_sql);
    $order_stmt->bind_param("idsss", $user_id, $total_price, $address, $payment_method, $status);
    $order_stmt->execute();
    $order_id = $order_stmt->insert_id;

    // Clear the cart
    $clear_cart_sql = "DELETE FROM cart WHERE user_id = ?";
    $clear_cart_stmt = $conn->prepare($clear_cart_sql);
    $clear_cart_stmt->bind_param("i", $user_id);
    $clear_cart_stmt->execute();

    // Redirect to order confirmation page
    header("Location: order_confirmation.php?order_id=" . $order_id);
    exit();
} else {
    echo "Invalid Request";
}
?>
