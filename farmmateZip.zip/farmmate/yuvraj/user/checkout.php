<?php
session_start();
include "../conn.php"; // Database connection

$user_id = $_SESSION['user_id']; // Ensure the user is logged in

// Fetch cart items
$sql = "SELECT * FROM cart1 WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$total_price = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 50%;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        table th {
            background: #007BFF;
            color: white;
        }
        .total {
            text-align: right;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            font-weight: bold;
            margin-top: 10px;
        }
        input, textarea, select {
            padding: 8px;
            width: 100%;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background: #28a745;
            color: white;
            padding: 10px;
            margin-top: 15px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 4px;
        }
        button:hover {
            background: #218838;
        }
    </style>
    <?php include 'head.php' ?>
</head>
<body>
    <div class="container">
    <?php include 'header.php' ?>
    <h2>Checkout</h2>

        <table>
            <tr>
                <th>Product Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): 
                $subtotal = $row['price'] * $row['quantity'];
                $total_price += $subtotal;
            ?>
            <tr>
                <td><?= htmlspecialchars($row['product_name']) ?></td>
                <td>$<?= number_format($row['price'], 2) ?></td>
                <td><?= $row['quantity'] ?></td>
                <td>$<?= number_format($subtotal, 2) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>

        <div class="total">Total: $<?= number_format($total_price, 2) ?></div>

        <h3>Billing Details</h3>
        <form action="process_checkout.php" method="POST">
            <input type="hidden" name="total_price" value="<?= $total_price ?>">

            <label>Address:</label>
            <textarea name="address" required></textarea>

            <label>Payment Method:</label>
            <select name="payment_method">
                <option value="cod">Cash on Delivery</option>
                <!-- <option value="paypal">PayPal</option> -->
            </select>

            <button type="submit">Place Order</button>
        </form>
    </div>

</body>
</html>
