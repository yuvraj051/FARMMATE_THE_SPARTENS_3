<?php
session_start();
include '../conn.php'; // Include database connection
include '..//user/session_check.php';
if (isset($_GET['pid'])) {
    $user_id = $_SESSION['user_id'] ?? 1; // Default user ID
    $product_id = $_GET['pid'];

    // Fetch product details from the database
    $query = "SELECT product_name, price FROM products WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        // Extract product details
        $product_name = $row['product_name'];
        $price = $row['price'];
        $quantity = 1;
        $created_at = date('Y-m-d H:i:s');

        // Check if product is already in the cart1
        $checkQuery = "SELECT id, quantity FROM cart1 WHERE user_id = ? AND product_id = ?";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("ii", $user_id, $product_id);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($row = $result->fetch_assoc()) {
            // Update quantity if product exists
            $newQuantity = $row['quantity'] + 1;
            $updateQuery = "UPDATE cart1 SET quantity = ? WHERE id = ?";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bind_param("ii", $newQuantity, $row['id']);
            $updateStmt->execute();
            $message = "cart1 updated!";
        } else {
            // Insert new product into cart1
            $insertQuery = "INSERT INTO cart1 (user_id, product_id, product_name, price, quantity, created_at) 
                            VALUES (?, ?, ?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bind_param("iisdis", $user_id, $product_id, $product_name, $price, $quantity, $created_at);
            
            if ($insertStmt->execute()) {
                $message = "Product added to cart1!";
            } else {
                $message = "Error adding to cart1.";
            }
        }
    } else {
        $message = "Product not found!";
    }
} else {
    $message = "Invalid product selection!";
}

// Redirect back to product page with message
header("Location: index.php?message=" . urlencode($message));
exit();
?>
