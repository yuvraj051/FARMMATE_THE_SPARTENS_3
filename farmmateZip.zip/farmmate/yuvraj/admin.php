<?php
//include 'conn.php';
//$hashed_password = password_hash("tushar@admin", PASSWORD_DEFAULT);
//$conn->query("INSERT INTO farmmate_hander (username, password) VALUES ('tushar', '$hashed_password')");
//echo "User added!";
?>

<?php
// Include the QR Code library
include "phpqrcode/qrlib.php";

// Text to encode
$text = "https://yourwebsite.com"; 

// File path to save the QR Code
$file = "qrcodes/my_qr.png";

// Generate QR Code
QRcode::png($text, $file, QR_ECLEVEL_L, 10, 2);

// Display QR Code
echo "<img src='$file' />";


?>
