<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Database Connection
include 'conn.php';

// Search Functionality
$search_query = isset($_GET["search"]) ? trim($_GET["search"]) : "";
$sql = "SELECT * FROM approved_farmer";
$params = [];

if ($search_query !== "") {
    $sql .= " WHERE firstname LIKE ? OR lastname LIKE ? OR mobilenumber LIKE ? OR village LIKE ? OR certificatenumber LIKE ?";
    $search_param = "%$search_query%";
    $params = [$search_param, $search_param, $search_param, $search_param, $search_param];
}

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param(str_repeat("s", count($params)), ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FarmMate | Farmers</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
   <?php include 'head.php' ?>
</head>
<body>
   <?php include 'header.php' ?>
    <div class="content">
        <h2 class="text-primary">👨‍🌾 Approved Farmers</h2>
        <form method="GET" class="search-bar d-flex">
            <input type="text" name="search" class="form-control me-2" 
                   value="<?php echo htmlspecialchars($search_query); ?>" placeholder="🔍 Search farmers...">
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
        <div class="table-container">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Village</th>
                        <th>Jilla</th>
                        <th>Certificate No.</th>
                        <th>Certificate</th>
                        <th>QR Code</th>
                        <th>Created</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$row["id"]}</td>
                                    <td>{$row["firstname"]} {$row["lastname"]}</td>
                                    <td>{$row["mobilenumber"]}</td>
                                    <td>{$row["village"]}</td>
                                    <td>{$row["jilla"]}</td>
                                    <td>{$row["certificatenumber"]}</td>
                                    <td><a href='../farmer/{$row["certificate_image"]}' target='_blank'>
                                        <img src='../farmer/{$row["certificate_image"]}' class='img-thumbnail'></a></td>
                                    <td><a href='../farmer/{$row["qrcode"]}' target='_blank'>
                                        <img src='../farmer/{$row["qrcode"]}' class='img-thumbnail'></a></td>
                                    <td>{$row["created_at"]}</td>
                                </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9' class='text-center text-danger'>No records found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

<?php $conn->close(); ?>
