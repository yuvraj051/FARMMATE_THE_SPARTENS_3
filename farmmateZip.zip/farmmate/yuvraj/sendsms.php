<?php
$phone = "9979108573"; // Receiver's phone number
$message = "Hello, this is a free SMS!";

$data = array("phone" => $phone, "message" => $message, "key" => "textbelt");
$ch = curl_init("https://textbelt.com/text");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

echo $response;
?>
