<div class="sidebar">
        <h2>FarmMate 🌿</h2>
        <a href="index.php">🏠 Dashboard</a>
        <a href="farmers.php">📋 Farmers</a>
        <a href="verify.php">📊 Request</a>
        <a href="delivery.php">delivery</a>
        <a href="logout.php">⚙️ logout</a>
    </div>