<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>FarmMate - Home</title>
    <?php include 'head.php' ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <?php include 'header.php' ?>
    <div class="container text-center mt-5">
        <h1 class="mb-3">Welcome to FarmMate</h1>
        <p class="lead">Manage farmer requests and view data.</p>
        
        <div class="d-flex justify-content-center gap-3">
            <a href="verify.php" class="btn btn-success">✅ Requests</a>
            <a href="farmers.php" class="btn btn-secondary">📋 View All Farmers</a>
        </div>
    </div>
</body>
</html>
