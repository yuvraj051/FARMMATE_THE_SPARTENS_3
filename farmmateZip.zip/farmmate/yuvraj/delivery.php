<?php
session_start();
include './conn.php';

// Ensure the user is logged in
if (!isset($_SESSION["user_id"])) {
    echo "<script>alert('Please login to view orders.'); window.location.href='login.php';</script>";
    exit;
}

$u = $_SESSION["user_id"];

// Query to fetch orders
$sql = "SELECT id, user_id, total_price, address, payment_method, status FROM orders"; 
$stmt = $conn->prepare($sql);
$stmt->execute();

// Fetch all orders
$orders = $stmt->get_result();

// Handle cancel order
if (isset($_GET['cancel_order_id'])) {
    $order_id = intval($_GET['cancel_order_id']); // Sanitize the order ID
    
    // Ensure the user can only cancel their own orders
    $check_order_sql = "SELECT user_id, status FROM orders WHERE id = ?";
    $check_stmt = $conn->prepare($check_order_sql);
    $check_stmt->bind_param("i", $order_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows > 0) {
        $order = $result->fetch_assoc();
        
        if ( $order['status'] !== 'Cancelled') {
            // Proceed with cancelling the order
            $cancel_sql = "UPDATE orders SET status = 'Cancelled' WHERE id = ?";
            $cancel_stmt = $conn->prepare($cancel_sql);
            $cancel_stmt->bind_param("i", $order_id);
            $cancel_stmt->execute();
            
            // Redirect to the same page to refresh the list
            header("Location: ".$_SERVER['PHP_SELF']);
            exit;
        } else {
            // Order already cancelled or user not authorized to cancel
            echo "<script>alert('You cannot cancel this order.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order List</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Styles -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7f7f7;
        }

        .container {
            margin-top: 50px;
        }

        .cancel-link {
            color: #dc3545;
            text-decoration: none;
        }

        .cancel-link:hover {
            text-decoration: underline;
        }

        footer {
            background-color: #333;
            color: white;
            padding: 15px 0;
            text-align: center;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">FarmMate</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link text-white" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="verify.php">Request</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="farmers.php">Farmers</a></li>
                <li class="nav-item"><a class="nav-link btn btn-danger text-white" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Main Container -->
<div class="container">
    <h2 class="text-center mb-4">Order List</h2>

    <!-- Order Table -->
    <table class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Total Price</th>
                <th>Address</th>
                <th>Payment Method</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($orders->num_rows > 0): ?>
                <?php while ($order = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($order['id']); ?></td>
                        <td><?php echo htmlspecialchars($order['user_id']); ?></td>
                        <td>$<?php echo number_format($order['total_price'], 2); ?></td>
                        <td><?php echo htmlspecialchars($order['address']); ?></td>
                        <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                        <td><?php echo htmlspecialchars($order['status']); ?></td>
                        <td>
                            <?php if ($order['status'] !== 'Cancelled'): ?>
                                <a href="?cancel_order_id=<?php echo $order['id']; ?>" class="cancel-link" onclick="return confirm('Are you sure you want to cancel this order?')">Cancel Order</a>
                            <?php else: ?>
                                <span class="text-muted">Order Cancelled</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">No orders found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="index.php" class="btn btn-primary">Back to Dashboard</a>
</div>

<!-- Bootstrap 5 JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

</body>
</html>
